package battlefield;

import static org.junit.Assert.*;

import java.text.FieldPosition;

import org.junit.*;

public class RobotOrdinatiPerPosizioneTest {
	
	@Test
	public void testCampoVuoto() {
		Battlefield campoVuoto = new Battlefield(2);
		assertTrue(campoVuoto.getRobotOrdinatiPerPosizione().isEmpty());
	}
	
	@Test
	public void testCampoUnRobot() {
		Battlefield campoUnitario = new Battlefield(2);
		campoUnitario.addChaser(new Chaser(new Position(0, 0)));
		assertEquals(1, campoUnitario.getRobotOrdinatiPerPosizione().size());
		assertEquals(new Chaser(new Position(0, 0)), campoUnitario.getRobotOrdinatiPerPosizione().get(0));
		
	}
	
	@Test
	public void testCampo2Robot() {
		Battlefield campo2 = new Battlefield(2);
		campo2.addChaser(new Chaser(new Position(0, 0)));
		campo2.addWalker(new Walker(new Position(1, 0)));
		assertEquals(2, campo2.getRobotOrdinatiPerPosizione().size());
		assertEquals(new Chaser(new Position(0, 0)), campo2.getRobotOrdinatiPerPosizione().get(0));
		assertEquals(new Walker(new Position(1, 0)), campo2.getRobotOrdinatiPerPosizione().get(1));
		
	}
	
	@Test
	public void testCampo4Robot() {
		Battlefield campo4 = new Battlefield(2);
		campo4.addChaser(new Chaser(new Position(0, 0)));
		campo4.addWalker(new Walker(new Position(1, 0)));
		campo4.addChaser(new Chaser(new Position(0, 1)));
		campo4.addWalker(new Walker(new Position(1, 1)));
		assertEquals(4, campo4.getRobotOrdinatiPerPosizione().size());
		assertEquals(new Chaser(new Position(0, 0)), campo4.getRobotOrdinatiPerPosizione().get(0));
		assertEquals(new Walker(new Position(1, 0)), campo4.getRobotOrdinatiPerPosizione().get(2));
		assertEquals(new Chaser(new Position(0, 1)), campo4.getRobotOrdinatiPerPosizione().get(1));
		assertEquals(new Walker(new Position(1, 1)), campo4.getRobotOrdinatiPerPosizione().get(3));
		
	}
	
	
	
}
