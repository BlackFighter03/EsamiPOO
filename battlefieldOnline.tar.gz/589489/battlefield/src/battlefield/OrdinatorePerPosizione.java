package battlefield;

import java.util.Comparator;

public class OrdinatorePerPosizione implements Comparator<Robot> {

	@Override
	public int compare(Robot o1, Robot o2) {
		return (o1.getPosizione().getX() == o2.getPosizione().getX()) ?
				o1.getPosizione().getY() - o2.getPosizione().getY() :
					o1.getPosizione().getX() - o2.getPosizione().getX();
	}

}
