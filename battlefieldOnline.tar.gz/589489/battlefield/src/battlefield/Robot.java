package battlefield;

public abstract class Robot implements Comparable<Robot> {
	private Position posizione;
	private int longevita;
	
	public Robot(Position p) {
		this.posizione = p;
		this.longevita = 0;
	}
	
	public Position getPosizione() {
		return this.posizione;
	}
	
	public int incrementaLongevita() {
		return ++this.longevita;
	}
	
	public int getLongevita() {
		return this.longevita;
	}
	
	public void passo(Battlefield field) {
		Position nuova = this.decidiMossa(field);
		if (nuova!=null) {
				Robot clone = this.clonazione(nuova);
				field.addRobot(clone);
		}
		this.incrementaLongevita();
	}

	protected abstract Robot clonazione(Position nuova);
	
	public abstract Position decidiMossa(Battlefield field);

	@Override
	public int hashCode() {
		return this.longevita + this.posizione.hashCode() + this.getClass().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Robot other = (Robot) obj;
		return longevita == other.getLongevita() && this.posizione.equals(other.getPosizione());
	}
	
	@Override
	public int compareTo(Robot r) {
		return this.longevita == r.getLongevita() ? new OrdinatorePerPosizione().compare(this, r) : this.longevita-r.getLongevita();
	}
	
}
