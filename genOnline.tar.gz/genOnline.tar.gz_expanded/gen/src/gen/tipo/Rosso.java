package gen.tipo;

import static gen.gui.CostantiGUI.RISORSA_IMMAGINE_ROSSO;
import static gen.gui.LettoreImmagini.leggiImmagineOggetto;

import java.awt.Image;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import gen.sim.Ambiente;
import gen.sim.Coordinate;

public class Rosso extends Animale {

	static final private Image IMMAGINE_ROSSA = leggiImmagineOggetto(RISORSA_IMMAGINE_ROSSO);

	private static int progId = 0;

	public Rosso(Ambiente ambiente) {
		super(ambiente, progId++);
	}

	@Override
	public Image getImmagine() {
		return IMMAGINE_ROSSA;
	}

	@Override
	public Animale creaClone() {
		return new Rosso(getAmbiente());
	}

	@Override
	protected Animale decidiProssimoObiettivo() {
		final List<Animale> all = new ArrayList<>(this.getAmbiente().getAllAnimali());
		Iterator<Animale> a = all.iterator();
		if(!all.isEmpty()) {
			while(a.hasNext()) {
				Animale animale = a.next();
				if(animale.getClass() == this.getClass())
					a.remove();
			}
			if(!all.isEmpty())
				return Collections.min(all, new Comparator<Animale>() {

					@Override
					public int compare(Animale o1, Animale o2) {
						return Double.compare(Coordinate.distanza(getPosizione(), o1.getPosizione()), Coordinate.distanza(getPosizione(), o2.getPosizione()));
					}
				});
		}
		return this;

	}

}
