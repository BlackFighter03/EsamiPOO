package gen.tipo;

import static gen.gui.CostantiGUI.RISORSA_IMMAGINE_VERDE;
import static gen.gui.LettoreImmagini.leggiImmagineOggetto;
import static gen.sim.CostantiSimulazione.MIN_ETA_RIPRODUZIONE;
import static gen.sim.GeneratoreCasuale.generaNumeroSinoA;

import java.awt.Image;
import java.util.ArrayList;
import java.util.List;

import gen.sim.Ambiente;

public class Verde extends Animale {

	static final private Image IMMAGINE_VERDE = leggiImmagineOggetto(RISORSA_IMMAGINE_VERDE);

	private static int progId = 0;

	public Verde(Ambiente ambiente) {
		super(ambiente, progId++);
	}

	@Override
	public Image getImmagine() {
		return IMMAGINE_VERDE;
	}

	@Override
	public Animale creaClone() {
		return new Verde(getAmbiente());
	}

	@Override
	protected Animale decidiProssimoObiettivo() {
		List<Animale> all = new ArrayList<>();
				if(this.getEta()<MIN_ETA_RIPRODUZIONE )
					all.addAll(this.getAnimaliDelTipoDiverso());
				else
					all.addAll(this.getAnimaliStessoTipo());
			if(!all.isEmpty())
				return all.get(generaNumeroSinoA(all.size()));
		return this;
	}

}
