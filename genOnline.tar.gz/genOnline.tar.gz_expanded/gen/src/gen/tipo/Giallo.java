package gen.tipo;

import java.awt.Image;
import java.util.ArrayList;
import java.util.List;

import static gen.gui.CostantiGUI.RISORSA_IMMAGINE_GIALLO;
import static gen.gui.LettoreImmagini.leggiImmagineOggetto;
import static gen.sim.GeneratoreCasuale.generaNumeroSinoA;

import gen.sim.Ambiente;

public class Giallo extends Animale {

	static final private Image IMMAGINE_GIALLA = leggiImmagineOggetto(RISORSA_IMMAGINE_GIALLO);

	private static int progId = 0;

	public Giallo(Ambiente ambiente) {
		super(ambiente, progId++);
	}

	@Override
	public Image getImmagine() {
		return IMMAGINE_GIALLA;
	}

	@Override
	public Animale creaClone() {
		return new Giallo(getAmbiente());
	}

	@Override
	protected Animale decidiProssimoObiettivo() {
		final List<Animale> all = new ArrayList<>(this.getAnimaliDelTipoDiverso());
			if(!all.isEmpty())
				return all.get(generaNumeroSinoA(all.size()));
		return this;
	}

}
