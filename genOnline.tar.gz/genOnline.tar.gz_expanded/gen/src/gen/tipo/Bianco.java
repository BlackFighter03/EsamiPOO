package gen.tipo;


import static gen.gui.CostantiGUI.RISORSA_IMMAGINE_BIANCO;
import static gen.gui.LettoreImmagini.leggiImmagineOggetto;
import static gen.sim.GeneratoreCasuale.generaNumeroSinoA;


import java.awt.Image;
import java.util.ArrayList;
import java.util.List;

import gen.sim.Ambiente;

public class Bianco extends Animale {

	static final private Image IMMAGINE_BIANCA = leggiImmagineOggetto(RISORSA_IMMAGINE_BIANCO);

	static private int progId = 0;

	public Bianco(Ambiente ambiente) {		
		super(ambiente, progId++);
	}

	public Animale creaClone() {
		return new Bianco(this.getAmbiente());
	}

	protected Animale decidiProssimoObiettivo() {
		final List<Animale> all = new ArrayList<>(this.getAnimaliStessoTipo());
			if(!all.isEmpty())
				return all.get(generaNumeroSinoA(all.size()));
		return this;
	}

	public Image getImmagine() {
		return IMMAGINE_BIANCA;
	}

}
