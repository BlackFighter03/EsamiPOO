package gen.stats;

import static gen.sim.CostantiSimulazione.MAX_ETA_RIPRODUZIONE;
import static gen.sim.CostantiSimulazione.MIN_ETA_RIPRODUZIONE;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.HashSet;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;

import gen.sim.Scontro;
import gen.tipo.*;

public class StatisticheTest {

	final static int ETA_OTTIMALE_PER_GLI_SCONTRI = ( MAX_ETA_RIPRODUZIONE - MIN_ETA_RIPRODUZIONE ) / 2;
	
	@SuppressWarnings("unused")
	private Statistiche stats;

	@Before
	public void setUp() {
		this.stats = new Statistiche();
	}
	
	@Test
	public void testScontriPerAnimale() {
		Animale rosso = new Rosso(null);
		rosso.setEta(ETA_OTTIMALE_PER_GLI_SCONTRI);
		Animale verde = new Verde(null);
		verde.setEta(ETA_OTTIMALE_PER_GLI_SCONTRI-2);
		Animale giallo = new Giallo(null);
		giallo.setEta(ETA_OTTIMALE_PER_GLI_SCONTRI-1);
		Set<Animale> animali1 = new HashSet<Animale>();
		Set<Animale> animali2 = new HashSet<Animale>();
		Set<Animale> animali3 = new HashSet<Animale>();
		animali1.add(rosso);
		animali1.add(verde);
		animali2.add(giallo);
		animali2.add(verde);
		animali3.add(rosso);
		animali3.add(giallo);
		Scontro s1 = new Scontro(animali1);
		Scontro s2 = new Scontro(animali2);
		Scontro s3 = new Scontro(animali3);
		Set<Scontro> scontri = new HashSet<>();
		scontri.add(s1);
		scontri.add(s2);
		scontri.add(s3);
		assertEquals(2, stats.scontriPerAnimale(scontri).size());
		assertTrue(stats.scontriPerAnimale(scontri).containsKey(rosso));
		assertTrue(stats.scontriPerAnimale(scontri).containsKey(giallo));
	
	}

}
