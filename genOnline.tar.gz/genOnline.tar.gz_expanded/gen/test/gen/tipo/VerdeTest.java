package gen.tipo;

import static org.junit.Assert.*;

import org.junit.Test;

import gen.sim.Ambiente;

import static gen.sim.CostantiSimulazione.MIN_ETA_RIPRODUZIONE;

public class VerdeTest {

	@Test
	public void testScegliProssimoObiettivoVuoto() {
		Animale animale = new Verde(new Ambiente());
		assertEquals(animale, animale.decidiProssimoObiettivo());
	}
	
	@Test
	public void testScegliProssimoObiettivoEtaGiovaneSoloVerde() {
		Ambiente a = new Ambiente();
		Verde v = new Verde(a);
		Verde verde = new Verde(a);
		a.add(v);
		assertEquals(verde, verde.decidiProssimoObiettivo());
	}
	
	@Test
	public void testScegliProssimoObiettivoEtaGiovaneAltroAnimale() {
		Ambiente a = new Ambiente();
		Giallo g = new Giallo(a);
		a.add(g);
		assertEquals(g, new Verde(a).decidiProssimoObiettivo());
	}
	
	@Test
	public void testScegliProssimoObiettivoEtaAdultaSoloVerde() {
		Ambiente a = new Ambiente();
		Verde verde = new Verde(a);
		verde.setEta(MIN_ETA_RIPRODUZIONE);
		Verde v = new Verde(a);
		a.add(v);
		assertEquals(v, verde.decidiProssimoObiettivo());
	}
	
	@Test
	public void testScegliProssimoObiettivoEtaAdultaAltroAnimale() {
		Ambiente a = new Ambiente();
		Verde verde = new Verde(a);
		verde.setEta(MIN_ETA_RIPRODUZIONE);
		Giallo g = new Giallo(a);
		a.add(g);
		assertEquals(verde, verde.decidiProssimoObiettivo());
	}

}
