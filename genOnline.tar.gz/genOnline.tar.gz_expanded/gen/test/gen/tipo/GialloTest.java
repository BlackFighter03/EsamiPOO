package gen.tipo;

import static org.junit.Assert.*;

import org.junit.Test;

import gen.sim.Ambiente;

public class GialloTest {

	@Test
	public void testScegliProssimoObiettivoVuoto() {
		Animale animale = new Giallo(new Ambiente());
		assertEquals(animale, animale.decidiProssimoObiettivo());
	}
	@Test
	public void testScegliProssimoObiettivoVerde() {
		Ambiente a = new Ambiente();
		Verde v = new Verde(a);
		a.add(v);
		assertEquals(v, new Giallo(a).decidiProssimoObiettivo());
	}
	
	@Test
	public void testScegliProssimoObiettivoNessuno() {
		Ambiente a = new Ambiente();
		Giallo g = new Giallo(a);
		Giallo giallo = new Giallo(a);
		a.add(g);
		assertEquals(giallo, giallo.decidiProssimoObiettivo());
	}

}
