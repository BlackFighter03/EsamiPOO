package gen.tipo;

import static org.junit.Assert.*;

import org.junit.Test;

import gen.sim.Ambiente;

public class RossoTest {

	@Test
	public void testScegliProssimoObiettivoVuoto() {
		Animale animale = new Rosso(new Ambiente());
		assertEquals(animale, animale.decidiProssimoObiettivo());
	}

}
