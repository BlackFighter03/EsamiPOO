package prop.pers;

import static org.junit.Assert.*;

import org.junit.Test;

import prop.sim.Ambiente;
import prop.sim.Coordinate;

public class PredicatoreTest {

	@Test
	public void testMovimentoDestra() {
		Ambiente ambiente = new Ambiente();
		Persona predicatore = new Predicatore(ambiente);
		predicatore.setPosizione(new Coordinate(2,2));
		Persona nonPredicatore = new NonPredicatore(ambiente);
		nonPredicatore.setPosizione(new Coordinate(4,2));
		ambiente.add(predicatore);
		ambiente.add(nonPredicatore);
		predicatore.mossa();
		assertTrue(new Coordinate(3,1).equals(predicatore.getPosizione()) || new Coordinate(3,3).equals(predicatore.getPosizione()));
	}

}
