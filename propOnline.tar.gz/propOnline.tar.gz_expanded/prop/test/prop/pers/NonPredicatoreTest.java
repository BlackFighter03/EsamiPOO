package prop.pers;

import static org.junit.Assert.*;

import org.junit.Test;

import prop.sim.Ambiente;
import prop.sim.Coordinate;

public class NonPredicatoreTest {

	@Test
	public void testMovimentoDestra() {
		Ambiente ambiente = new Ambiente();
		Persona predicatore = new Predicatore(ambiente);
		predicatore.setPosizione(new Coordinate(2,2));
		Persona nonPredicatore = new NonPredicatore(ambiente);
		nonPredicatore.setPosizione(new Coordinate(4,2));
		ambiente.add(predicatore);
		ambiente.add(nonPredicatore);
		nonPredicatore.mossa();
		assertTrue(new Coordinate(5,1).equals(nonPredicatore.getPosizione()) || new Coordinate(5,3).equals(nonPredicatore.getPosizione()));
	}

}
