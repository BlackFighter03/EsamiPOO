package prop.stats;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;

import prop.pers.*;
import prop.sim.Contatto;

public class StatisticheTest {

	@SuppressWarnings("unused")
	private Statistiche stats;

	@Before
	public void setUp() {
		this.stats = new Statistiche();
	}
	
	@Test
	public void testProduciStatistica() {
		Persona predicatore1 = new Predicatore(null);
		Persona nonPredicatore1 = new NonPredicatore(null);
		Persona nonPredicatore2 = new NonPredicatore(null);
		Set<Persona> coinvolti1 = new HashSet<>();
		coinvolti1.add(predicatore1);
		coinvolti1.add(nonPredicatore1);
		Contatto contatto1 = new Contatto(0, coinvolti1, null);
		Set<Persona> coinvolti2a = new HashSet<>();
		coinvolti2a.add(predicatore1);
		coinvolti2a.add(nonPredicatore2);
		Contatto contatto2a = new Contatto(1, coinvolti2a, null);
		Set<Persona> coinvolti2b = new HashSet<>();
		coinvolti2b.add(predicatore1);
		coinvolti2b.add(nonPredicatore2);
		coinvolti2b.add(nonPredicatore1);
		Contatto contatto2b = new Contatto(1, coinvolti2b, null);
		Set<Persona> coinvolti3 = new HashSet<>();
		coinvolti3.add(nonPredicatore2);
		coinvolti3.add(nonPredicatore1);
		Contatto contatto3 = new Contatto(3, coinvolti3, null);
		
		List<Contatto> contatti = new ArrayList<>();
		contatti.add(contatto1);
		contatti.add(contatto2a);
		contatti.add(contatto2b);
		contatti.add(contatto3);
		assertEquals(3, stats.produciStatistiche(contatti).size());
	}

}
