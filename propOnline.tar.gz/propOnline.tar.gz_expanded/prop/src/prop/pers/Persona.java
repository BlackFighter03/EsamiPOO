package prop.pers;

import java.awt.Image;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import static prop.sim.GeneratoreCasuale.*;
import static  prop.gui.CostantiGUI.*;

import prop.sim.Ambiente;
import prop.sim.Contatto;
import prop.sim.Coordinate;

public abstract class Persona {

	private final int id;
	private Ambiente ambiente;
	private Coordinate posizione;    // posizione corrente
	
	public Persona(Ambiente ambiente, int progId) {
		this.ambiente = ambiente;
		this.posizione = posizioneCasuale();
		this.id = progId;
	}
	
	public Ambiente getAmbiente() {
		return this.ambiente;
	}
	
	public int getId() {
		return this.id;
	}

	public Coordinate getPosizione() {
		return this.posizione;
	}

	public void setPosizione(Coordinate nuova) {
		this.posizione = nuova;
	}

	@Override
	public String toString() {
		return this.getClass().getSimpleName()+getId();
	}
	
	public abstract Image getImmagine();

	public abstract void mossa();

	public void avvenuto(Contatto contatto) {
		if(this.getClass() == Predicatore.class)
			return;
		for(Persona p : contatto.getCoinvolti())
			if(p.getClass() == Predicatore.class && siVerificaEventoDiProbabilita(PROBABILITA_CONVERSIONE))
				this.conversione();
		
	}

	
	
	@Override
	public int hashCode() {
		return this.id + this.posizione.hashCode() + this.getClass().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Persona other = (Persona) obj;
		return this.ambiente.equals(other.getAmbiente()) && id == other.getId() && this.posizione.equals(other.getPosizione());
	}
	
	protected List<Persona> getPersoneAltroTipo() {
		List<Persona> persone = new ArrayList<>(this.getAmbiente().getAllPersone());
		Iterator<Persona> it = persone.iterator();
		while(it.hasNext()) {
			Persona p = it.next();
			if(p.getClass() == this.getClass() || p == this)
				it.remove();
		}
		return persone;
	}

	public abstract void conversione();
	
}
