package prop.pers;

import static prop.gui.CostantiGUI.*;
import static prop.gui.LettoreImmagini.leggiImmagineOggetto;

import java.awt.Image;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import prop.sim.Ambiente;
import prop.sim.Coordinate;

public class NonPredicatore extends Persona {

	static final private Image IMMAGINE_BIANCA = leggiImmagineOggetto(RISORSA_IMMAGINE_BIANCO);
	static final private Image IMMAGINE_GIALLA = leggiImmagineOggetto(RISORSA_IMMAGINE_GIALLO);
	static private int progId = 0;
	private boolean convertito;

	public NonPredicatore(Ambiente ambiente) {		
		super(ambiente, progId++);
		this.convertito = false;
	}

	public Image getImmagine() {
		return this.convertito ? IMMAGINE_GIALLA : IMMAGINE_BIANCA;
	}

	public void mossa() {
		List<Coordinate> adiacenti = new LinkedList<>(this.getAmbiente().adiacentiA(this.getPosizione()));
		List<Persona> persone = this.getPersoneAltroTipo();
		final Persona personaVicinaMin = Collections.min(persone, new Comparator<Persona>() {

			@Override
			public int compare(Persona o1, Persona o2) {
				if(Coordinate.distanza(getPosizione(), o1.getPosizione()) - Coordinate.distanza(getPosizione(), o2.getPosizione()) == 0)
					return -1;
				return (int) (Coordinate.distanza(getPosizione(), o1.getPosizione()) - Coordinate.distanza(getPosizione(), o2.getPosizione()));
			}
		});
		
		Collections.shuffle(adiacenti);
		
		Coordinate coordinataMigliore = Collections.max(adiacenti, new Comparator<Coordinate>() {

			@Override
			public int compare(Coordinate o1, Coordinate o2) {
				if(Coordinate.distanza(o1, personaVicinaMin.getPosizione()) - Coordinate.distanza(o2, personaVicinaMin.getPosizione()) == 0)
					return -1;
				return (int) (Coordinate.distanza(o1, personaVicinaMin.getPosizione()) - Coordinate.distanza(o2, personaVicinaMin.getPosizione()));
			}
		});
		this.setPosizione(coordinataMigliore);
	}

	@Override
	public void conversione() {
		this.convertito = true;
		
	}


}
