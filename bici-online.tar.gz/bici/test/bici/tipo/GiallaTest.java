package bici.tipo;

import static org.junit.Assert.*;

import org.junit.Test;

public class GiallaTest {

	@Test
	public void testScegliProssimaDestinazioneContenutaInQuelleDiDefault() {
		assertTrue(Gialla.DESTINAZIONI.contains(new Gialla(null).decidiProssimaDestinazione()));
	}
	
	@Test
	public void testScegliProssimaDestinazionePer2GialleDiverse() {
		assertEquals(new Gialla(null).decidiProssimaDestinazione(), new Gialla(null).decidiProssimaDestinazione());
	}
}
