package bici.stats;

import static org.junit.Assert.assertEquals;

import java.util.HashSet;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;

import bici.sim.Coordinate;
import bici.sim.Percorso;
import bici.tipo.Bianca;
import bici.tipo.Gialla;

public class StatisticheTest {

	@SuppressWarnings("unused")
	private Statistiche stats;

	@Before
	public void setUp() {
		this.stats = new Statistiche();
	}

	@Test
	public void testPercorsoPerBici() {
		Percorso p1 = new Percorso(new Bianca(null), new Coordinate(0, 0), new Coordinate(1, 0));
		Percorso p2 = new Percorso(new Gialla(null), new Coordinate(0, 1), new Coordinate(1, 1));
		Percorso p3 = new Percorso(new Gialla(null), new Coordinate(2, 1), new Coordinate(1, 3));
		Set<Percorso> percorsi = new HashSet<>();
		percorsi.add(p1);
		percorsi.add(p2);
		percorsi.add(p3);
		assertEquals(3, stats.percorsiPerBici(percorsi).size());
		assertEquals(3, stats.percorsiPerBici(percorsi).values().size());
	}

}
