package bici.tipo;

import static bici.gui.LettoreImmagini.leggiImmagineBici;

import java.awt.Image;
import java.util.List;

import static bici.sim.CostantiSimulazione.N_DESTINAZIONI;
import bici.sim.Coordinate;
import bici.sim.GeneratoreCasuale;
import bici.sim.Zona;

public class Gialla extends Bici {

	static final protected List<Coordinate> DESTINAZIONI = GeneratoreCasuale.generaNposizioniCasuali(N_DESTINAZIONI);
	static final private Image IMMAGINE_BICI_GIALLA = leggiImmagineBici(java.awt.Color.YELLOW);
	private static int progId = 0;
	
	private int countDest;

	public Gialla(Zona zona) {
		super(zona, progId++);
		countDest = 0;
	}

	@Override
	protected Coordinate decidiProssimaDestinazione() {
		return DESTINAZIONI.get(countDest++ % N_DESTINAZIONI);
	}

	@Override
	public Image getImmagine() {
		return IMMAGINE_BICI_GIALLA;
	}

}
