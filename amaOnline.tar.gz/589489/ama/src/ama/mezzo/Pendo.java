package ama.mezzo;

import java.awt.Image;

import ama.Citta;
import ama.Posizione;

import static ama.costanti.CostantiGUI.IMMAGINE_CAMION_ROSSO;;

public class Pendo extends Politica {

	private static int progId = 0;
	private int inversione;

	public Pendo(Citta citta) {
		super(citta, progId++);
		this.inversione = 1;
	}

	@Override
	public Image getImmagine() {
		return IMMAGINE_CAMION_ROSSO;
	}

	@Override
	public Posizione decidiDirezione(Posizione corrente) {
		if(this.getCitta().sulBordo(corrente.traslazioneUnitaria(this.inversione*corrente.getX(), 0)))
			this.inversione = this.inversione*(-1);
		return corrente.traslazioneUnitaria(this.inversione*corrente.getX(), 0);
	}
}
