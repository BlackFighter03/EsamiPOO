package ama.mezzo;

import java.awt.Image;
import java.util.Random;

import ama.Citta;
import ama.Posizione;

public abstract class Politica {

	private int id;
	private Citta citta;
	
	final private Random rnd;

	public Politica(Citta citta, int progId, Random rnd) {
		this.citta = citta;
		this.id = progId;
		this.rnd = rnd;
	}
	
	public Politica(Citta citta, int progId) {
		this(citta, progId, new Random());
	}

	public int getId() {
		return this.id;
	}
	
	public Citta getCitta() {
		return this.citta;
	}
	
	/**
	 * 
	 * @return un numero intero casuale tra -1,0,+1
	 */
	protected int deltaCasuale() {
		return this.rnd.nextInt(3)-1;
	}
	
	@Override
	public String toString() {
		return getClass().getSimpleName()+getId();
	}
	
	public abstract Image getImmagine();

	public Posizione decidiDirezione(Posizione corrente) {
		return corrente.traslazioneUnitaria(deltaCasuale(),deltaCasuale());
	}
	
}
