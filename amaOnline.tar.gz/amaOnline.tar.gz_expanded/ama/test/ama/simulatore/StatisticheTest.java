package ama.simulatore;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.HashSet;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.xml.sax.HandlerBase;

import ama.Posizione;
import ama.rifiuto.Carta;
import ama.rifiuto.Organico;
import ama.rifiuto.Rifiuto;
import ama.rifiuto.Vetro;

public class StatisticheTest {

	private Simulatore simulatore;

	private Statistiche stats;	
	
	final static private Posizione ORIGINE = new Posizione(0, 0);
	
	@Before
	public void setUp() throws Exception {
		this.stats = new Statistiche();
		this.simulatore = new Simulatore();
	}

	/* N.B. E' POSSIBILE USARE I  METODI CHE SEGUONO (E CREARNE DI SIMILARI) 
	 * PER VELOCIZZARE IL TESTING RELATIVO ALLE DOMANDE 3 E SUCCESSIVE */
	private Carta creaCartaRaccoltoDaBrowniano() {
		final Carta rifiuto = new Carta(ORIGINE);
		rifiuto.setRaccoltoDa(this.simulatore.creaBrowniano());	
		return rifiuto;
	}
	
	private Carta creaCartaRaccoltoDaPendo() {
		final Carta rifiuto = new Carta(ORIGINE);
		rifiuto.setRaccoltoDa(this.simulatore.creaPendo());	
		return rifiuto;
	}

	
	private Carta creaCartaRaccoltoDaChaser() {
		final Carta rifiuto = new Carta(ORIGINE);
		rifiuto.setRaccoltoDa(this.simulatore.creaChaser());	
		return rifiuto;
	}
	
	private Organico creaOrganicoRaccoltoDaBrowniano() {
		final Organico rifiuto = new Organico(ORIGINE);
		rifiuto.setRaccoltoDa(this.simulatore.creaBrowniano());	
		return rifiuto;
	}
	
	private Organico creaOrganicoRaccoltoDaPendo() {
		final Organico rifiuto = new Organico(ORIGINE);
		rifiuto.setRaccoltoDa(this.simulatore.creaPendo());	
		return rifiuto;
	}

	
	private Organico creaOrganicoRaccoltoDaChaser() {
		final Organico rifiuto = new Organico(ORIGINE);
		rifiuto.setRaccoltoDa(this.simulatore.creaChaser());	
		return rifiuto;
	}
	
	private Vetro creaVetroRaccoltoDaBrowniano() {
		final Vetro rifiuto = new Vetro(ORIGINE);
		rifiuto.setRaccoltoDa(this.simulatore.creaBrowniano());	
		return rifiuto;
	}
	
	private Vetro creaVetroRaccoltoDaPendo() {
		final Vetro rifiuto = new Vetro(ORIGINE);
		rifiuto.setRaccoltoDa(this.simulatore.creaPendo());	
		return rifiuto;
	}

	
	private Vetro creaVetroRaccoltoDaChaser() {
		final Vetro rifiuto = new Vetro(ORIGINE);
		rifiuto.setRaccoltoDa(this.simulatore.creaChaser());	
		return rifiuto;
	}
	
	/* N.B. E' POSSIBILE USARE I METODI SOPRA (E CREARNE DI SIMILARI) 
	 * PER VELOCIZZARE IL TESTING RELATIVO ALLE DOMANDE 3 E SUCCESSIVE */
	
	@Test
	public void testRaccoltoPerMezzo() {
		Set<Rifiuto> smaltiti = new HashSet<>();
		smaltiti.add(creaCartaRaccoltoDaBrowniano());
		smaltiti.add(creaOrganicoRaccoltoDaChaser());
		smaltiti.add(creaVetroRaccoltoDaPendo());
		assertEquals(3, stats.raccoltoPerMezzo(smaltiti).size());
	}

	
	@Test
	public void testRaccoltoPerPolitica() {
		Set<Rifiuto> smaltiti = new HashSet<>();
		smaltiti.add(creaCartaRaccoltoDaBrowniano());
		assertEquals(1, stats.raccoltoPerPolitica(smaltiti).size());
		smaltiti.add(creaOrganicoRaccoltoDaChaser());
		assertEquals(2, stats.raccoltoPerPolitica(smaltiti).size());
		smaltiti.add(creaCartaRaccoltoDaChaser());
		assertEquals(2, stats.raccoltoPerPolitica(smaltiti).size());
		smaltiti.add(creaVetroRaccoltoDaPendo());
		assertEquals(3, stats.raccoltoPerPolitica(smaltiti).size());
	}
	
	@Test
	public void testRaccoltoPerPoliticaVuoto() {
		assertTrue(stats.raccoltoPerPolitica(null).isEmpty());
	}
	
	@Test
	public void testOrdinaPolitichePerRaccoltaVuoto() {
		assertTrue(stats.ordinaPolitichePerRaccolta(null).isEmpty());
	}
	
	@Test
	public void testOrdinaRaccoltoPerMezzoVuoto() {
		assertTrue(stats.raccoltoPerMezzo(null).isEmpty());
	}


}
