package simulazione.esemplare;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import simulazione.modello.Ambiente;
import simulazione.modello.Coordinate;

public class RossoTest {

	private Ambiente ambiente;
	private Verde verde;
	private Rosso rosso;
	
	@Before
	public void setUp() {
		this.ambiente = new Ambiente();
		this.rosso = new Rosso(ambiente);
		this.verde = new Verde(ambiente);
		this.ambiente.add(rosso);
		this.ambiente.add(verde);
	}
	
	@Test
	public void spostamentoVersoIlVerde() {
		verde.setPosizione(new Coordinate(5, 5));
		rosso.setPosizione(new Coordinate(3, 3));
		rosso.mossa();
		assertEquals(new Coordinate(4, 4),rosso.getPosizione());
	}
	
	@Test
	public void spostamentoVersoIlGiallo() {
		Giallo giallo = new Giallo(ambiente);
		ambiente.add(giallo);
		giallo.setPosizione(new Coordinate(7, 7));
		verde.setPosizione(new Coordinate(2, 1));
		rosso.setPosizione(new Coordinate(3, 3));
		rosso.mossa();
		assertEquals(new Coordinate(4, 4),rosso.getPosizione());
	}


}
