package simulazione.esemplare;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import simulazione.modello.Ambiente;
import simulazione.modello.Coordinate;

public class GialloTest {

	private Ambiente ambiente;
	private Giallo giallo;
	private Bianco bianco;
	
	@Before
	public void setUp() {
		this.ambiente = new Ambiente();
		this.bianco = new Bianco(ambiente);
		this.giallo = new Giallo(ambiente);
		this.ambiente.add(bianco);
		this.ambiente.add(giallo);
	}

	@Test
	public void testSpostamentoADestraStessaLinea() {
		giallo.setPosizione(new Coordinate(2, 3));
		bianco.setPosizione(new Coordinate(4, 3));
		giallo.mossa();
		assertEquals(new Coordinate(3, 3),giallo.getPosizione());
		
	}
	
	@Test
	public void testSpostamentoADestraLivelliDiversi() {
		giallo.setPosizione(new Coordinate(2, 3));
		bianco.setPosizione(new Coordinate(4, 5));
		giallo.mossa();
		assertEquals(new Coordinate(3, 3),giallo.getPosizione());
		
	}
	
	@Test
	public void testSpostamentoASinistraStessaLinea() {
		giallo.setPosizione(new Coordinate(4, 3));
		bianco.setPosizione(new Coordinate(2, 3));
		giallo.mossa();
		assertEquals(new Coordinate(3, 3),giallo.getPosizione());
		
	}
	
	@Test
	public void testSpostamentoASinistraLivelliDiversi() {
		giallo.setPosizione(new Coordinate(4, 3));
		bianco.setPosizione(new Coordinate(2, 5));
		giallo.mossa();
		assertEquals(new Coordinate(3, 3),giallo.getPosizione());
		
	}


}
