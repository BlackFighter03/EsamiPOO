package simulazione.esemplare;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import simulazione.modello.Ambiente;

/** 
 * <B>(VEDI DOMANDA 2)</B>
 */
public class EsemplareTest {

	private Ambiente ambiente;
	private static Bianco bianco1;
	
	@Before
	public void setUp() throws Exception {
		this.ambiente = new Ambiente();
		if(bianco1 == null)
			bianco1 = new Bianco(ambiente);
	}

	@Test
	public void testIdProgressiviStessoTipo() {
		assertEquals(0, bianco1.getId());
		assertEquals(1, new Bianco(ambiente).getId());
	}
	
	@Test
	public void testIdProgressiviTipoDiverso() {
		assertEquals(0, bianco1.getId());
		assertEquals(0, new Giallo(ambiente).getId());
	}
	

}
