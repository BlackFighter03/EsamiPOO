package simulazione.esemplare;

import static org.junit.Assert.*;

import java.util.Set;

import org.junit.Before;
import org.junit.Test;

import simulazione.modello.Ambiente;
import simulazione.modello.Coordinate;

public class BiancoTest {
	
	private Ambiente ambiente;
	private Bianco bianco;
	
	@Before
	public void setUp() {
		this.ambiente = new Ambiente();
		this.bianco = new Bianco(ambiente);
	}

	@Test
	public void test4DirezioniPossibili() {
		bianco.setPosizione(new Coordinate(3, 3));
		Set<Coordinate> possibiliCoordinate = ambiente.adiacentiA(new Coordinate(3, 3));
		bianco.mossa();
		assertTrue(possibiliCoordinate.contains(bianco.getPosizione()));
		
	}
	
	@Test
	public void test1DirezionePossibile() {
		bianco.setPosizione(new Coordinate(1, 1));
		Set<Coordinate> possibiliCoordinate = ambiente.adiacentiA(new Coordinate(1, 1));
		bianco.mossa();
		assertEquals(new Coordinate(2, 2),bianco.getPosizione());
		
	}


}
