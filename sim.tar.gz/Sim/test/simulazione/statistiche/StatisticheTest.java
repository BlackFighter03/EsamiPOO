package simulazione.statistiche;

import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

public class StatisticheTest {

	@SuppressWarnings("unused")
	private Statistiche stats;

	@Before
	public void setUp() {
		this.stats = new Statistiche();
	}
	
	@Test
	public void testProduciStatistica() {
		// DA COMPLETARE ( VEDI DOMANDA 3 )
		fail("DA COMPLETARE");
	}

}
