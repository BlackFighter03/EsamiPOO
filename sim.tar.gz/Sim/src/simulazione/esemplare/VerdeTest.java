package simulazione.esemplare;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import simulazione.modello.Ambiente;
import simulazione.modello.Coordinate;

public class VerdeTest {

	private Ambiente ambiente;
	private Verde verde;
	private Rosso rosso;
	
	@Before
	public void setUp() {
		this.ambiente = new Ambiente();
		this.rosso = new Rosso(ambiente);
		this.verde = new Verde(ambiente);
		this.ambiente.add(rosso);
		this.ambiente.add(verde);
	}

	@Test
	public void testSpostamentoInAltoStessaLinea() {
		verde.setPosizione(new Coordinate(3, 1));
		rosso.setPosizione(new Coordinate(3, 3));
		verde.mossa();
		assertEquals(new Coordinate(3, 2),verde.getPosizione());
		
	}
	
	@Test
	public void testSpostamentoInAltoLivelliDiversi() {
		verde.setPosizione(new Coordinate(5, 1));
		rosso.setPosizione(new Coordinate(4, 3));
		verde.mossa();
		assertEquals(new Coordinate(5, 2),verde.getPosizione());
		
	}
	
	@Test
	public void testSpostamentoInBassoStessaLinea() {
		verde.setPosizione(new Coordinate(3, 3));
		rosso.setPosizione(new Coordinate(3, 1));
		verde.mossa();
		assertEquals(new Coordinate(3, 2),verde.getPosizione());
		
	}
	
	@Test
	public void testSpostamentoInBassoLivelliDiversi() {
		verde.setPosizione(new Coordinate(5, 3));
		rosso.setPosizione(new Coordinate(4, 1));
		verde.mossa();
		assertEquals(new Coordinate(5, 2),verde.getPosizione());
		
	}

}
