package simulazione.esemplare;

import static simulazione.gui.CostantiGUI.RISORSA_IMMAGINE_BIANCO;
import static simulazione.gui.LettoreImmagini.leggiImmagineOggetto;

import java.awt.Image;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import simulazione.modello.Ambiente;
import simulazione.modello.Coordinate;

public class Bianco extends Esemplare {

	static final private Image IMMAGINE_BIANCA = leggiImmagineOggetto(RISORSA_IMMAGINE_BIANCO);
	
	static private int progId = 0;


	public Bianco(Ambiente ambiente) {		
		super(ambiente, progId++);
	}

	public Image getImmagine() {
		return IMMAGINE_BIANCA;
	}

	public void mossa() {
		/* si muove casualmente */
		List<Coordinate> adiacenti = new LinkedList<>(this.getAmbiente().adiacentiA(this.getPosizione()));
		Collections.shuffle(adiacenti);
		this.setPosizione(adiacenti.get(0));
	}

}
