package simulazione.esemplare;

import static simulazione.gui.CostantiGUI.RISORSA_IMMAGINE_VERDE;
import static simulazione.gui.LettoreImmagini.leggiImmagineOggetto;

import java.awt.Image;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import simulazione.modello.Ambiente;
import simulazione.modello.Coordinate;

public class Verde extends Esemplare {

	static final private Image IMMAGINE_VERDE = leggiImmagineOggetto(RISORSA_IMMAGINE_VERDE);

	static private int progId = 0;

	public Verde(Ambiente ambiente) {
		super(ambiente, progId++);
	}

	@Override
	public Image getImmagine() {
		return IMMAGINE_VERDE;
	}

	@Override
	public void mossa() {
		if(this.getObiettivo() == null) {
			List<Esemplare> esemplari = new ArrayList<Esemplare>(this.getAmbiente().getAll());
			Iterator<Esemplare> itEsemplare = esemplari.iterator();
			while(itEsemplare.hasNext())
				if(itEsemplare.next().getClass() != Rosso.class)
					itEsemplare.remove();
			Collections.shuffle(esemplari);
			this.setObiettivo(esemplari.get(0));
		}
		final Esemplare obiettivo = this.getObiettivo();
		List<Coordinate> adiacenti = new ArrayList<Coordinate>(this.getAmbiente().adiacentiA(getPosizione()));
		for(Coordinate c : adiacenti)
			if(c.getX() != this.getPosizione().getX())
				c.setX(this.getPosizione().getX());;
				Coordinate posizionePiuVicina = Collections.min(adiacenti, new Comparator<Coordinate>() {

					@Override
					public int compare(Coordinate o1, Coordinate o2) {
						return (int) (Coordinate.distanza(o1, obiettivo.getPosizione()) - Coordinate.distanza(o2, obiettivo.getPosizione()));
					}
				});

				this.setPosizione(posizionePiuVicina);
	}

}
