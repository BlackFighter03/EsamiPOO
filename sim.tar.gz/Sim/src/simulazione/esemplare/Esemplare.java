package simulazione.esemplare;

import java.awt.Image;

import simulazione.modello.Ambiente;
import simulazione.modello.Coordinate;
import simulazione.modello.GeneratoreCasuale;

public abstract class Esemplare {
	private final int id;

	private Ambiente ambiente;
	private Coordinate posizione;    // posizione corrente
	private	Esemplare obiettivo;

	public Esemplare(Ambiente ambiente, int progId) {
		this.ambiente = ambiente;
		this.posizione = GeneratoreCasuale.posizione();
		this.id = progId;
		obiettivo = null;
	}

	public Esemplare getObiettivo() {
		return obiettivo;
	}

	public void setObiettivo(Esemplare obiettivo) {
		this.obiettivo = obiettivo;
	}

	public Ambiente getAmbiente() {
		return this.ambiente;
	}

	public int getId() {
		return this.id;
	}

	public Coordinate getPosizione() {
		return this.posizione;
	}

	public void setPosizione(Coordinate nuova) {
		this.posizione = nuova;
	}

	@Override
	public String toString() {
		return this.getClass().getSimpleName()+getId();
	}

	public abstract Image getImmagine();
	public abstract void mossa();

}
