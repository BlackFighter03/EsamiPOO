package simulazione.esemplare;

import java.awt.Image;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import simulazione.modello.Ambiente;
import simulazione.modello.Coordinate;
import simulazione.modello.GeneratoreCasuale;

public abstract class Esemplare {
	private final int id;

	private Ambiente ambiente;
	private Coordinate posizione;    // posizione corrente
	private	Esemplare obiettivo;

	public Esemplare(Ambiente ambiente, int progId) {
		this.ambiente = ambiente;
		this.posizione = GeneratoreCasuale.posizione();
		this.id = progId;
		obiettivo = null;
	}

	public Esemplare getObiettivo() {
		return obiettivo;
	}

	public void setObiettivo(Esemplare obiettivo) {
		this.obiettivo = obiettivo;
	}

	public Ambiente getAmbiente() {
		return this.ambiente;
	}

	public int getId() {
		return this.id;
	}

	public Coordinate getPosizione() {
		return this.posizione;
	}

	public void setPosizione(Coordinate nuova) {
		this.posizione = nuova;
	}

	@Override
	public String toString() {
		return this.getClass().getSimpleName()+getId();
	}

	protected List<Esemplare> getEsemplareTipoSpecifico(Class<? extends Esemplare> classeDesiderata) {
		List<Esemplare> esemplari = new ArrayList<Esemplare>(this.getAmbiente().getAll());
		Iterator<Esemplare> itEsemplare = esemplari.iterator();
		while(itEsemplare.hasNext())
			if(itEsemplare.next().getClass() != classeDesiderata)
				itEsemplare.remove();
		return esemplari;
	}
	
	protected void impostaObiettivo(Class<? extends Esemplare> classeDesiderata) {
		List<Esemplare> esemplari = this.getEsemplareTipoSpecifico(classeDesiderata);
		Collections.shuffle(esemplari);
		this.setObiettivo(esemplari.get(0));
	}
	
	public abstract Image getImmagine();
	public abstract void mossa();

}
