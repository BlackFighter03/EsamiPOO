package simulazione.esemplare;

import static simulazione.gui.CostantiGUI.RISORSA_IMMAGINE_ROSSO;
import static simulazione.gui.LettoreImmagini.leggiImmagineOggetto;

import java.awt.Image;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import simulazione.modello.Ambiente;
import simulazione.modello.Coordinate;

public class Rosso extends Esemplare {

	static final private Image IMMAGINE_ROSSA = leggiImmagineOggetto(RISORSA_IMMAGINE_ROSSO);

	static private int progId = 0;

	public Rosso(Ambiente ambiente) {
		super(ambiente, progId++);
	}

	@Override
	public Image getImmagine() {
		return IMMAGINE_ROSSA;
	}

	@Override
	public void mossa() {
		List<Esemplare> esemplari = new ArrayList<Esemplare>(this.getAmbiente().getAll());
		esemplari.removeAll(this.getEsemplareTipoSpecifico(Rosso.class));
		final Esemplare esemplarePiuLontano = Collections.max(esemplari, new Comparator<Esemplare>() {

			@Override
			public int compare(Esemplare o1, Esemplare o2) {
				if(Coordinate.distanza(o1.getPosizione(), getPosizione()) - Coordinate.distanza(o2.getPosizione(), getPosizione()) == 0)
						return -1;
				return (int) (Coordinate.distanza(o1.getPosizione(), getPosizione()) - Coordinate.distanza(o2.getPosizione(), getPosizione()));
			}
		});
		
		this.setObiettivo(esemplarePiuLontano);
		List<Coordinate> adiacenti = new ArrayList<Coordinate>(this.getAmbiente().adiacentiA(getPosizione()));
		Coordinate posizionePiuVicina = Collections.min(adiacenti, new Comparator<Coordinate>() {

			@Override
			public int compare(Coordinate o1, Coordinate o2) {
				return (int) (Coordinate.distanza(o1, esemplarePiuLontano.getPosizione()) - Coordinate.distanza(o2, esemplarePiuLontano.getPosizione()));
			}
		});
		this.setPosizione(posizionePiuVicina);
	}

}
