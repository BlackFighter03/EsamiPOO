package simulazione.statistiche;

import java.util.*;

import simulazione.esemplare.Esemplare;
import simulazione.modello.Contatto;
import simulazione.modello.Simulatore;

/**
 * <B>DA COMPLETARE (VEDI DOMANDA 3)</B>
 */
public class Statistiche {

	synchronized public void stampaFinale(Simulatore simulatore) {
		final List<Contatto> contatti = simulatore.getContatti();

		System.out.println(contatti.size() + " contatti rilevati." );
		System.out.println(simulatore.getContatti());
		System.out.println();

		final Map<Class<? extends Esemplare>,SortedSet<Contatto>> mappa = produciStatistiche(simulatore.getContatti());
		System.out.println("Contatti per esemplare:");
		stampaStatistiche(mappa);
		System.out.println();
	}

	public Map<Class<? extends Esemplare>,SortedSet<Contatto>> produciStatistiche(Collection<Contatto> contatti) {
		Map<Class<? extends Esemplare>,SortedSet<Contatto>> tipo2contatti = new HashMap<Class<? extends Esemplare>,SortedSet<Contatto>>();
		for(Contatto c : contatti) {
			Set<Esemplare> esemplari = c.getCoinvolti();
			for(Esemplare e : esemplari) {
				SortedSet<Contatto> tmp = tipo2contatti.get(e.getClass());
				if(tmp == null) tmp = new TreeSet<Contatto>(new Comparator<Contatto>() {

					@Override
					public int compare(Contatto o1, Contatto o2) {
						if(o1 == o2)
							return 0;
						if(o1.getPasso() == o2.getPasso())
							return -1;
						return o1.getPasso() - o2.getPasso();
					}
				});
				tmp.add(c);
				tipo2contatti.put(e.getClass(), tmp);
			}
		}
		
		return tipo2contatti;
	}

	/**
	 * <EM>N.B. UTILE PER STAMPARE E QUINDI CONTROLLARE 
	 *          EVENTUALI RISULTATI DELLA DOMANDA 3</EM>
	 */
	private void stampaStatistiche(final Map<Class<? extends Esemplare>,SortedSet<Contatto>>mappa) {
		for(Class<? extends Esemplare> k : mappa.keySet()) {
			final SortedSet<Contatto> c = mappa.get(k);
			System.out.print(k + "  :");
			for(Contatto v : c) 
				System.out.print(v.toString() + " ");
			System.out.println();
		}
	}
}
