package war;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import war.tank.Explorer;
import war.tank.Tank;

public class CampoTest {
	
	private Campo campo;
	
	@Before
	public void setUp() throws Exception {
		this.campo = new Campo(5);
	}

	@Test
	public void testNonRilevaNessunaTraccia() {
		assertEquals(0, this.campo.rilevaTracciaVerso(new Coordinate(1, 1), new Direzione(1,1)));
	}
	
	@Test
	public void testRilevaTracciaNuovaInUnaDirezione() {
		Tank explorer = new Explorer(campo);
		explorer.setPosizione(new Coordinate(2, 2));
		this.campo.lasciaTraccia(explorer);
		assertEquals(25, this.campo.rilevaTracciaVerso(new Coordinate(1, 1), new Direzione(1,1)));
	}
	@Test
	public void testRilevaTracciaVecchiaDi1InUnaDirezione() {
		Tank explorer = new Explorer(campo);
		explorer.setPosizione(new Coordinate(2, 2));
		this.campo.lasciaTraccia(explorer);
		this.campo.dissipazioneTracce();
		assertEquals(24, this.campo.rilevaTracciaVerso(new Coordinate(1, 1), new Direzione(1,1)));
	}

}
