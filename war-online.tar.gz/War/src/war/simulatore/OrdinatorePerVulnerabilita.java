package war.simulatore;

import java.util.Comparator;
import java.util.Map;
import java.util.Set;

import war.Proiettile;
import war.tank.Factory;
import war.tank.Factory.Fazione;

public class OrdinatorePerVulnerabilita implements Comparator<Factory.Fazione> {
	
	final private Map<Fazione, Set<Proiettile>> c2p;
	
	public OrdinatorePerVulnerabilita(Map<Fazione, Set<Proiettile>> c2p) {
		this.c2p = c2p;
	}
	
	@Override
	public int compare(Fazione o1, Fazione o2) {
		return c2p.get(o2).size() - c2p.get(o1).size();
	}
}
