package war.tank;

import static war.costanti.CostantiSimulazione.PROBABILITA_CAMBIO_DIREZIONE;
import static war.simulatore.GeneratoreCasuale.siVerificaEventoDiProbabilita;

import java.util.Set;

import war.Campo;
import war.Direzione;

public class Gunner extends Tank {

	public Gunner(Campo campo) {
		super(campo);
	}

	@Override
	public boolean decideDiSparare(int passo) {
		for(Tank t : this.getCampo().getTank()) {
			if(this.getClass() != t.getClass() && this.getDirezione().equals(new Direzione(this.getPosizione(), t.getPosizione())))
				return true;
		}
		return false;
	}

	@Override
	public boolean decideDiCambiareDirezione(int passo) {
		return (siVerificaEventoDiProbabilita(PROBABILITA_CAMBIO_DIREZIONE) );
	}

	@Override
	public Direzione cambioDirezione(Set<Direzione> possibili) {
		return Direzione.scegliAcasoTra(possibili);
	}

}
