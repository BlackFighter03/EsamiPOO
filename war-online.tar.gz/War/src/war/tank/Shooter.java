package war.tank;

import static war.costanti.CostantiSimulazione.PROBABILITA_CAMBIO_DIREZIONE;
import static war.costanti.CostantiSimulazione.PROBABILITA_SPARO;
import static war.simulatore.GeneratoreCasuale.siVerificaEventoDiProbabilita;

import java.util.Collections;
import java.util.Comparator;
import java.util.Set;

import war.Campo;
import war.Direzione;
import war.simulatore.GeneratoreCasuale;

public class Shooter extends Tank {

	public Shooter(Campo campo) {
		super(campo);
	}

	@Override
	public boolean decideDiSparare(int passo) {
		return GeneratoreCasuale.siVerificaEventoDiProbabilita(PROBABILITA_SPARO) ;
	}

	@Override
	public boolean decideDiCambiareDirezione(int passo) {
		return this.getCampo().rilevaTracciaVerso(getPosizione(), getDirezione()) != 0 ? false : siVerificaEventoDiProbabilita(PROBABILITA_CAMBIO_DIREZIONE); 
	}

	@Override
	public Direzione cambioDirezione(Set<Direzione> possibili) {
		Direzione opposta = this.getDirezione().opposta();
		possibili.remove(opposta);
		if(possibili.isEmpty())
			return opposta;
		return Collections.max(possibili, new Comparator<Direzione>() {
			@Override
			public int compare(Direzione o1, Direzione o2) {
				return getCampo().rilevaTracciaVerso(getPosizione(), o1) - getCampo().rilevaTracciaVerso(getPosizione(), o2); 
			}
		});
	}

}
