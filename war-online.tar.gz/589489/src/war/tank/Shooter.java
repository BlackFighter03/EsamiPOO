package war.tank;

import static war.costanti.CostantiSimulazione.PROBABILITA_SPARO;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

import war.Campo;
import war.Coordinate;
import war.Direzione;
import war.simulatore.GeneratoreCasuale;

public class Shooter extends Tank {
	
	private static int progId = 0;

	public Shooter(Campo campo) {
		super(campo, progId++);
	}

	@Override
	public boolean decideDiSparare(int passo) {
		return GeneratoreCasuale.siVerificaEventoDiProbabilita(PROBABILITA_SPARO);
	}

	@Override
	public boolean decideDiCambiareDirezione(int passo) {
		List<Direzione> possibili = new ArrayList<>(this.getCampo().getPossibiliDirezioni(getPosizione()));
		final Coordinate pos = this.getPosizione();
		final Campo c = this.getCampo();
		Direzione d = Collections.max(possibili, new Comparator<Direzione>() {
			@Override
			public int compare(Direzione o1, Direzione o2) {
				return c.rilevaTracciaVerso(pos, o1) - c.rilevaTracciaVerso(pos, o2);
			}
		});
		return (!d.equals(this.getDirezione())) ? true : false;
	}

	@Override
	public Direzione cambioDirezione(Set<Direzione> possibili) {
		for(Direzione direzione : possibili)
			if(decideDiCambiareDirezione(this.getCampo().getTraccia(getPosizione())) && !direzione.equals(this.getDirezione().opposta()))
				return direzione;
		return Direzione.scegliAcasoTra(possibili);
	}

}
