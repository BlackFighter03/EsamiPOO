package war;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import war.tank.Shooter;
import war.tank.Tank;

public class CampoTest {
	
	private Campo campo;
	
	@Before
	public void setUp() throws Exception {
		this.campo = new Campo(3);
	}

	@Test
	public void testNessunaTraccia() {
		Tank t = new Shooter(campo);
		assertEquals(0, campo.rilevaTracciaVerso(t.getPosizione(), t.getDirezione()));
	}
	
	@Test
	public void testLasciaTracciaIndietro() {
		Tank t = new Shooter(campo);
		t.getCampo().lasciaTraccia(t);
		t.setPosizione(t.getPosizione().trasla(t.getDirezione()));
		assertEquals(25, campo.rilevaTracciaVerso(t.getPosizione(), t.getDirezione().opposta()));
	}
	@Test
	public void testTracciaRilasciata2Volte() {
		Tank t = new Shooter(campo);
		t.getCampo().lasciaTraccia(t);
		t.getCampo().lasciaTraccia(t);
		t.setPosizione(t.getPosizione().trasla(t.getDirezione()));
		assertEquals(50, campo.rilevaTracciaVerso(t.getPosizione(), t.getDirezione().opposta()));
	}

}
